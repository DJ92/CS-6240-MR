import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by DJ on 2/3/17.
 * This is the Mapper Class for MapReduce SecondarySort version program
 * It extends the Mapper Class
 */
public class SecondarySortMapperClass extends Mapper<Object,Text,SecondarySortKeyClass,StationInputDataWritableClass> {

    //Initialize Key Fields
    private Text stationID = new Text();
    private IntWritable year = new IntWritable(0);

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {

        //Reads one record at a time from the input chunk
        String line = value.toString();
        String[] lineArr = line.split(",");

        //Form the Key Object
        stationID = new Text(lineArr[0]);
        year = new IntWritable(Integer.parseInt(lineArr[1].substring(0,4)));
        SecondarySortKeyClass secondarySortKeyClass = new SecondarySortKeyClass();

        if(lineArr[2].equals("TMAX")){
            //Emit (Key Object with stationId and year values,Object with TMAX Values)
            secondarySortKeyClass.setStationID(stationID);
            secondarySortKeyClass.setYear(year);
            StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
            stationInputDataWritableClass.setTmaxsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
            stationInputDataWritableClass.setTmaxcount(new IntWritable(1));
            context.write(secondarySortKeyClass,stationInputDataWritableClass);
        }
        if(lineArr[2].equals("TMIN")){
            //Emit (Key Object with stationId and year values,Object with TMIN Values)
            secondarySortKeyClass.setStationID(stationID);
            secondarySortKeyClass.setYear(year);
            StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
            stationInputDataWritableClass.setTminsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
            stationInputDataWritableClass.setTmincount(new IntWritable(1));
            context.write(secondarySortKeyClass,stationInputDataWritableClass);
        }
    }
}
