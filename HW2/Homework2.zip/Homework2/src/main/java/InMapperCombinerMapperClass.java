import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by DJ on 2/3/17
 * This is the Mapper Class for The MapReduce InMapperCombiner version program
 */
public class InMapperCombinerMapperClass extends Mapper<Object, Text,Text, StationInputDataWritableClass> {
    private Text stationID = new Text();
    //HashMap to combine values locally at the map task level
    private Map<Text,StationInputDataWritableClass> accMap;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        //Initialize HashMap to accumulate values locally for same stationId's
        accMap = new HashMap<>();
    }
    @Override
    public void map(Object key, Text value, Context context)
            throws InterruptedException, IOException {

        //Reads one record at a time from the input chunk
        String line = value.toString();
        String[] lineArr = line.split(",");
        stationID= new Text(lineArr[0]);
        if(lineArr[2].equals("TMAX")){
            //Add (stationdID,Object with TMAX Values) to HashMap
            if(accMap.containsKey(stationID)){
                StationInputDataWritableClass stationInputDataWritableClass = accMap.get(stationID);
                stationInputDataWritableClass.setTmaxsum(new DoubleWritable(Double.parseDouble(lineArr[3])+stationInputDataWritableClass.getTmaxsum().get()));
                stationInputDataWritableClass.setTmaxcount(new IntWritable(1+stationInputDataWritableClass.getTmaxcount().get()));
                accMap.put(stationID,stationInputDataWritableClass);
            }else{
                StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
                stationInputDataWritableClass.setTmaxsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
                stationInputDataWritableClass.setTmaxcount(new IntWritable(1));
                accMap.put(stationID,stationInputDataWritableClass);
            }
        }
        if(lineArr[2].equals("TMIN")){
            //Add (stationdID,Object with TMIN Values) to HashMap
            if(accMap.containsKey(stationID)){
                StationInputDataWritableClass stationInputDataWritableClass = accMap.get(stationID);
                stationInputDataWritableClass.setTminsum(new DoubleWritable(Double.parseDouble(lineArr[3])+stationInputDataWritableClass.getTminsum().get()));
                stationInputDataWritableClass.setTmincount(new IntWritable(1+stationInputDataWritableClass.getTmincount().get()));
                accMap.put(stationID,stationInputDataWritableClass);
            }else{
                StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
                stationInputDataWritableClass.setTminsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
                stationInputDataWritableClass.setTmincount(new IntWritable(1));
                accMap.put(stationID,stationInputDataWritableClass);
            }
        }
    }
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        super.cleanup(context);
        //Emit(stationID,Object with combined values) to Reducer
        for(Map.Entry<Text,StationInputDataWritableClass> entry: accMap.entrySet()){
            context.write(entry.getKey(),entry.getValue());
        }
    }

}
