import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

/**
 * Created by DJ on 2/3/17.
 * This is the Group Comparator Class for MapReduce SecondarySort version program
 * It extends the WritableComparator Class
 */
public class SecondarySortGroupComparatorClass extends WritableComparator {
    protected SecondarySortGroupComparatorClass(){
        super(SecondarySortKeyClass.class,true);
    }

    @Override
    public int compare(WritableComparable w1, WritableComparable w2) {
        //Compares the two keys and groups based on the stationID
       SecondarySortKeyClass ip1 = (SecondarySortKeyClass) w1;
       SecondarySortKeyClass ip2 = (SecondarySortKeyClass) w2;
       return ip1.getStationID().toString().compareTo(ip2.getStationID().toString());
    }
}
