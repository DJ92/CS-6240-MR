import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by DJ on 2/3/17.
 * This is the Reducer Class for MapReduce NoCombiner version program
 */
public class NoCombinerReducerClass extends Reducer<Text,StationInputDataWritableClass,Text,StationOutputDataWritableClass> {
    public void reduce(Text key, Iterable<StationInputDataWritableClass> values,Context context
    ) throws IOException, InterruptedException {
        StationOutputDataWritableClass stationOutputDataWritableClass;
        //Initialize Sum & count Accumulators
        double tmaxsum = 0;
        double tminsum = 0;
        int tmaxcount = 0;
        int tmincount = 0;
        for (StationInputDataWritableClass val : values) {

            //Accumulate all values for a station
            tmaxsum += val.getTmaxsum().get();
            tmaxcount +=val.getTmaxcount().get();
            tminsum += val.getTminsum().get();
            tmincount += val.getTmincount().get();
        }
        //Emit (Station,TminAvg,TmaxAvg)
        stationOutputDataWritableClass = new StationOutputDataWritableClass();
        stationOutputDataWritableClass.setTmaxAvg(new DoubleWritable(tmaxsum/tmaxcount));
        stationOutputDataWritableClass.setTminAvg(new DoubleWritable(tminsum/tmincount));
        context.write(key, stationOutputDataWritableClass);
    }
}
