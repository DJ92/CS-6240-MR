import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by DJ on 2/3/17.
 * This class specifies the composite fields for the key and extends the WritableComparable interface
 * This is the Key Class for MapReduce SecondarySort version program
 */
public class SecondarySortKeyClass implements WritableComparable {

    //Fields
    private Text stationID;
    private IntWritable year;

    //Default Constructor
    public SecondarySortKeyClass(){
        stationID = new Text();
        year = new IntWritable(0);
    }

    public SecondarySortKeyClass(Text stationID, IntWritable year){
        this.stationID= stationID;
        this.year = year;
    }

    public Text getStationID() {
        return stationID;
    }

    public void setStationID(Text stationID) {
        this.stationID = stationID;
    }

    public IntWritable getYear() {
        return year;
    }

    public void setYear(IntWritable year) {
        this.year = year;
    }

    //Write function for MapReduce
    @Override
    public void write(DataOutput dataOutput) throws IOException {
        stationID.write(dataOutput);
        year.write(dataOutput);
    }

    //Read function for MapReduce
    @Override
    public void readFields(DataInput dataInput) throws IOException {
        stationID.readFields(dataInput);
        year.readFields(dataInput);
    }

    @Override
    public int compareTo(Object o) {
        //Compares the key object with the current value
        SecondarySortKeyClass secondarySortKeyClass = (SecondarySortKeyClass) o;
        int result = stationID.toString().compareTo(secondarySortKeyClass.getStationID().toString());
        //if both the stationId's are same then sort on associated year
        if(0 == result) {
            result = year.compareTo(secondarySortKeyClass.getYear());
        }
        return result;
    }
}
