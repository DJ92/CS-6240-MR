import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Created by DJ on 2/3/17.
 * This is the Combiner Class which also extends the Reducer Class
 * It is basically a reduce call with its and input and output types being the same
 * Note: MapReduce doesn't gurantee it's execution
 */
public class CombinerClass extends Reducer<Text,StationInputDataWritableClass,Text,StationInputDataWritableClass> {
    public void reduce(Text key, Iterable<StationInputDataWritableClass> values,Context context
    ) throws IOException, InterruptedException {
        StationInputDataWritableClass stationInputDataWritableClass;
        //Initialize Sum & count Accumulators
        double tmaxsum = 0;
        double tminsum = 0;
        int tmaxcount = 0;
        int tmincount = 0;

        //Iterate over values with similar stationID
        for (StationInputDataWritableClass val : values) {

            //Combine values
            tmaxsum += val.getTmaxsum().get();
            tmaxcount +=val.getTmaxcount().get();
            tminsum += val.getTminsum().get();
            tmincount += val.getTmincount().get();
        }

        //Update InputWritable Object
        stationInputDataWritableClass = new StationInputDataWritableClass();
        stationInputDataWritableClass.setTmaxsum(new DoubleWritable(tmaxsum));
        stationInputDataWritableClass.setTmaxcount(new IntWritable(tmaxcount));
        stationInputDataWritableClass.setTminsum(new DoubleWritable(tminsum));
        stationInputDataWritableClass.setTmincount(new IntWritable(tmincount));

        //Emit(stationId, Object with combined values)
        context.write(key, stationInputDataWritableClass);
    }
}
