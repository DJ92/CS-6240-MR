import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DJ on 2/3/17.
 * This is the Reducer Class for MapReduce SecondarySort version program
 * It extends the Reducer Class
 */
public class SecondarySortReducerClass extends Reducer<SecondarySortKeyClass,StationInputDataWritableClass,Text,Text> {

    @Override
    protected void reduce(SecondarySortKeyClass key, Iterable<StationInputDataWritableClass> values, Context context) throws IOException, InterruptedException {
        //List for accumulating avg temperatures for each year
        List<String> output = new ArrayList<>();

        //Track current year of the key
        int curryear = key.getYear().get();

        StationOutputDataWritableClass stationOutputDataWritableClass;

        //Initialize Sum & count Accumulators
        double tmaxsum = 0;
        double tminsum = 0;
        int tmaxcount = 0;
        int tmincount = 0;
        for (StationInputDataWritableClass val : values) {
            //if the year in the same station grouped data changes, dump value into list
            //sequence is trivial because it's sorted.
            if(curryear != key.getYear().get()){
                stationOutputDataWritableClass = new StationOutputDataWritableClass();
                stationOutputDataWritableClass.setTmaxAvg(new DoubleWritable(tmaxsum/tmaxcount));
                stationOutputDataWritableClass.setTminAvg(new DoubleWritable(tminsum/tmincount));

                //Add to list
                output.add("("+curryear+","+stationOutputDataWritableClass.toString()+")");

                //Reinitialize Accumulators
                tmaxsum = 0;
                tminsum = 0;
                tmaxcount = 0;
                tmincount = 0;

                //Set current year to the new year in the Key
                curryear = key.getYear().get();
            }
                //Accumulate all values for a station
                tmaxsum += val.getTmaxsum().get();
                tmaxcount +=val.getTmaxcount().get();
                tminsum += val.getTminsum().get();
                tmincount += val.getTmincount().get();
        }
        //if the last value isn't added to the list and accumulators still hold a value, dump it into the list
        if(tmaxsum !=0 || tminsum != 0){
            stationOutputDataWritableClass = new StationOutputDataWritableClass();
            stationOutputDataWritableClass.setTmaxAvg(new DoubleWritable(tmaxsum/tmaxcount));
            stationOutputDataWritableClass.setTminAvg(new DoubleWritable(tminsum/tmincount));
            //Add to list
            output.add("("+curryear+","+stationOutputDataWritableClass.toString()+")");
        }
        //Emit(stationId,list of years with min and max mean values)
        context.write(key.getStationID(),new Text(output.toString()));
    }
}
