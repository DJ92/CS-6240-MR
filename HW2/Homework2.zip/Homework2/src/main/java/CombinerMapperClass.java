import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * Created by DJ on 2/3/17.
 * This is the Mapper Class for The MapReduce Combiner version program
 */
public class CombinerMapperClass extends Mapper<Object, Text,Text, StationInputDataWritableClass> {
    private Text stationID = new Text();
    public void map(Object key, Text value, Context context)
            throws InterruptedException, IOException {

        //Reads one record at a time from the input chunk
        String line = value.toString();
        String[] lineArr = line.split(",");
        if(lineArr[2].equals("TMAX")){

            //Emit (stationdID,Object with TMAX Values)
            stationID.set(lineArr[0]);
            StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
            stationInputDataWritableClass.setTmaxsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
            stationInputDataWritableClass.setTmaxcount(new IntWritable(1));
            context.write(stationID,stationInputDataWritableClass);
        }
        if(lineArr[2].equals("TMIN")){

            //Emit (stationdID,Object with TMIN Values)
            stationID.set(lineArr[0]);
            StationInputDataWritableClass stationInputDataWritableClass = new StationInputDataWritableClass();
            stationInputDataWritableClass.setTminsum(new DoubleWritable(Double.parseDouble(lineArr[3])));
            stationInputDataWritableClass.setTmincount(new IntWritable(1));
            context.write(stationID,stationInputDataWritableClass);
        }
    }
}
