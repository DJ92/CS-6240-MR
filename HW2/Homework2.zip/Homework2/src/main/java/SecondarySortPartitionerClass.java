import org.apache.hadoop.mapreduce.Partitioner;

/**
 * Created by DJ on 2/3/17.
 * This is the Partitioner Class for MapReduce SecondarySort version program
 * It extends the Partitioner Class
 */
public class SecondarySortPartitionerClass extends Partitioner<SecondarySortKeyClass,StationInputDataWritableClass> {

    @Override
    public int getPartition(SecondarySortKeyClass secondarySortKeyClass, StationInputDataWritableClass stationInputDataWritableClass, int i) {
        //Returns partitioned data based on stationId
        return (secondarySortKeyClass.getStationID().toString().hashCode() & Integer.MAX_VALUE)%i;
    }
}
