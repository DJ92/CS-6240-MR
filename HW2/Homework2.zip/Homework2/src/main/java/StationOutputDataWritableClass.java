import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by DJ on 1/30/17.
 * This is the StationOutputData Class for writing the TMAX and TMIN averages to the output from the reducers.
 * It extends the Writable Class
 */
public class StationOutputDataWritableClass implements Writable{

    //Fields
    private DoubleWritable tminAvg;
    private DoubleWritable tmaxAvg;

    //Default Constructor
    public StationOutputDataWritableClass(){
        tminAvg = new DoubleWritable(0);
        tmaxAvg = new DoubleWritable(0);
    }

    public DoubleWritable getTminAvg() {
        return tminAvg;
    }

    public void setTminAvg(DoubleWritable tminAvg) {
        this.tminAvg = tminAvg;
    }

    public DoubleWritable getTmaxAvg() {
        return tmaxAvg;
    }

    public void setTmaxAvg(DoubleWritable tmaxAvg) {
        this.tmaxAvg = tmaxAvg;
    }

    //Read Function for MapReduce
    public void readFields(DataInput in) throws IOException {
        tmaxAvg.readFields(in);
        tminAvg.readFields(in);

    }
    //Write Function for MapReduce
    public void write(DataOutput out) throws IOException {
        tmaxAvg.write(out);
        tminAvg.write(out);
    }

    @Override
    public String toString() {
        return  tminAvg + "," + tmaxAvg;
    }
}
