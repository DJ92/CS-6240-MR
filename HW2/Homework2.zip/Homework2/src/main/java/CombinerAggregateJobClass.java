import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

/**
 * Created by DJ on 2/3/17.
 * This class sets the specifications for the Job Class
 * This is the main Class for MapReduce Combiner version program
 */
public class CombinerAggregateJobClass {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf = new Configuration();
        conf.set("mapred.textoutputformat.separator", ",");
        Job job = Job.getInstance(conf, "combiner");

        //Main Class/ Job Name
        job.setJarByClass(CombinerAggregateJobClass.class);

        //Mapper Class
        job.setMapperClass(CombinerMapperClass.class);
        job.setMapOutputValueClass(StationInputDataWritableClass.class);

        //Combiner Class
        job.setCombinerClass(CombinerClass.class);

        //Reducer Class
        job.setReducerClass(CombinerReducerClass.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(StationOutputDataWritableClass.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
