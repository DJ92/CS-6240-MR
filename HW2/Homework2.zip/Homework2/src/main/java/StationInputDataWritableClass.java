import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by DJ on 1/24/17.
 * This is the Universal StationDataInput Class and it extends the Writable Class.
 * It consists of the corresponding TMAX and TMIN Sum & Count respectively and provides get() and set() functions.
 */
public class StationInputDataWritableClass implements Writable{

    //Fields
    private DoubleWritable tmaxsum;
    private IntWritable tmaxcount;
    private DoubleWritable tminsum;
    private IntWritable tmincount;

    //Default Constructor
    public StationInputDataWritableClass(){
        tmaxsum = new DoubleWritable(0);
        tmaxcount = new IntWritable(0);
        tminsum = new DoubleWritable(0);
        tmincount = new IntWritable(0);
    }

    public DoubleWritable getTmaxsum() {
        return tmaxsum;
    }

    public void setTmaxsum(DoubleWritable tmaxsum) {
        this.tmaxsum = tmaxsum;
    }

    public IntWritable getTmaxcount() {
        return tmaxcount;
    }

    public void setTmaxcount(IntWritable tmaxcount) {
        this.tmaxcount = tmaxcount;
    }

    public DoubleWritable getTminsum() {
        return tminsum;
    }

    public void setTminsum(DoubleWritable tminsum) {
        this.tminsum = tminsum;
    }

    public IntWritable getTmincount() {
        return tmincount;
    }

    public void setTmincount(IntWritable tmincount) {
        this.tmincount = tmincount;
    }

    //Read Function for MapReduce
    public void readFields(DataInput in) throws IOException {
        tmaxsum.readFields(in);
        tmaxcount.readFields(in);
        tminsum.readFields(in);
        tmincount.readFields(in);
    }
    //Write Function for MapReduce
    public void write(DataOutput out) throws IOException {
        tmaxsum.write(out);
        tmaxcount.write(out);
        tminsum.write(out);
        tmincount.write(out);
    }

    @Override
    public String toString() {
        return "StationTMAXDataClass{" +
                "tmaxsum=" + tmaxsum +
                ", tmaxcount=" + tmaxcount +
                ", tminsum=" + tminsum +
                ", tmincount=" + tmincount +
                '}';
    }
}
