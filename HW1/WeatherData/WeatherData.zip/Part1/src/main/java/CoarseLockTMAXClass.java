import java.util.*;

/**
 * Created by DJ on 1/25/17.
 * This is the Multithreaded TMAX Average Calculation of Stations with a Coarse Lock Implementation
 */
public class CoarseLockTMAXClass {

    //Shared SynchronizedMap for accumulating sums and counts of all stations
    //The SynchronizedMap guarantees that each atomic operation you want to run on the map will be synchronized.
    //Running two (or more) operations/threads on the map however, must be synchronized in a block.
    public static Map<String,StationTMAXDataClass> resultMap = Collections.synchronizedMap(new HashMap<>());

    //Number of Threads for parallel execution
    int noThreads = 4;

    //Array of CoarseLockedTMAXAvgThreadClass
    CoarseLockedTMAXAvgThreadClass[] coarseLockedTMAXAvgThreadClasses = new CoarseLockedTMAXAvgThreadClass[noThreads];

    //Array of Thread Class
    Thread[] t= new Thread[noThreads];

    //Constructor
    public CoarseLockTMAXClass(List<String> listContent) throws InterruptedException {
        System.out.print("COARSE LOCK: ");

        //List of Subsets from the consolidated list of strings
        List<List<String>> subset = new ArrayList<>();

        //Default size of each subset
        int size = listContent.size()/noThreads;

        //Staring Execution Time
        Long start = System.currentTimeMillis();

        //Loop to instantiate total number of threads
        for (int k=0;k<noThreads;k++){

            //Condition for last subset
            if(k==noThreads-1)
                subset.add(listContent.subList(size*k, listContent.size()));
            else
                subset.add(listContent.subList(size*k, size*(k+1)));

            //Instantiate CoarseLockedTMAXAvgThreadClass with subset
            coarseLockedTMAXAvgThreadClasses[k] = new CoarseLockedTMAXAvgThreadClass(subset.get(k));

            //Get Thread instance
            t[k]=new Thread(coarseLockedTMAXAvgThreadClasses[k]);

            //Start Thread Execution
            t[k].start();

            //Join Thread to main thread
            t[k].join();
        }

        //Call to function calculating TMAX Average of all Stations
        Map<String,Double> avgResult = calculateAVG(resultMap);

        //Total Time Taken for Execution
        System.out.println(System.currentTimeMillis()-start);

        //Block for printing all averages
        /*for (String key : avgResult.keySet()) {
            System.out.println(key + "," + avgResult.get(key));
        }*/
    }

    //Helper Function
    public Map<String,Double> calculateAVG(Map<String,StationTMAXDataClass> resultMap){

        //Map for storing average of each station
        Map<String,Double> tempMap= new HashMap();

        //Iterate through the Accumulated Map of all Stations
        for(String key: resultMap.keySet()){

            //Get Value Object
            StationTMAXDataClass stationTMAXDataClass = resultMap.get(key);

            //Calculate Average for that Station
            Double avg= stationTMAXDataClass.getSum()/stationTMAXDataClass.getCount();

            //Add average to Map
            tempMap.put(key,avg);
        }

        //return resulting Map
        return tempMap;
    }
}
