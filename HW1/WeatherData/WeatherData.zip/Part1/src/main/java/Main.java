/**
 * Created by DJ on 1/24/17.
 * This is the Main Class.
 * All versions of executions have been instantiated in this class based on iterations specified.
 */

import java.util.*;

public class Main {

    //Main Function
    public static void main(String[] args) {
        try {

            //Runtime Argument
            String filename = args[0];

            //Loads the File into a list of strings
            LoadFileClass lf = new LoadFileClass();
            List<String> listContent = lf.getListOfContent(filename);

            //Sequential - Average Calculation x10
            for (int i = 0; i < 10; i++) {
                SequentialTMAXClass seq = new SequentialTMAXClass(listContent);
            }

            //No Lock - Average Calculation x10
            for (int i = 0; i < 10; i++) {
                NoLockTMAXClass noLockTMAXClass = new NoLockTMAXClass(listContent);
            }

            //Coarse Lock - Average Calculation x10
            for (int i = 0; i < 10; i++) {
                CoarseLockTMAXClass coarseLockTMAXClass = new CoarseLockTMAXClass(listContent);
            }

            //Fine Lock - Average Calculation x10
            for (int i = 0; i < 10; i++) {
                FineLockTMAXClass fineLockTMAXClass = new FineLockTMAXClass(listContent);
            }

            //No Sharing - Average Calculation x10
            for (int i = 0; i < 10; i++) {
                NoSharingTMAXClass noSharingTMAXClass = new NoSharingTMAXClass(listContent);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
