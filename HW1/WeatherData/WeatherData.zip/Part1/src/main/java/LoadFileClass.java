import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

/**
 * Created by DJ on 1/24/17.
 * This is LoadFile Class.
 * It reads the gzip file in a BufferedReader and returns a list of strings.
 */
public class LoadFileClass {

    //List Object
    List<String> listContent;

    //Function to process file content into a BufferedReader and return a list of strings.
    public List<String> getListOfContent(String filename) {

        //Instantiation
        listContent = new ArrayList<String>();

        try {

            //Reading the Gzip File into Input Stream
            FileInputStream file = new FileInputStream(filename);
            GZIPInputStream gzip = new GZIPInputStream(file);
            InputStreamReader reader = new InputStreamReader(gzip);
            BufferedReader brFile = new BufferedReader(reader);

            //Read file content line by line and add to a list
            String line = null;
            while ((line = brFile.readLine()) != null) {
                listContent.add(line);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        //return the generated list
        return listContent;
    }
}
