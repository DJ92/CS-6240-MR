
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by DJ on 1/24/17.
 * This is the Sequential Execution for Average Calculation.
 * The constructor takes in list of strings and calculates the average TMAX for each Station.
 */
public class SequentialTMAXClass {

    //Contructor
    public SequentialTMAXClass(List<String> listContent) {
        System.out.print("SEQUENTIAL: ");

        //Map for storing resulting Sums and Counts for each Station.
        Map<String, StationTMAXDataClass> resultMap = new HashMap();

        //Starting Execution Time
        Long start = System.currentTimeMillis();

        //Loop for iterating through list of strings and accumulating "TMAX" Sums & Counts of all Stations.
        for (String s : listContent) {

            //Split each String
            String[] strArr = s.split(",");

            //Check for TMAX value rows
            if (strArr[2].equals("TMAX"))
                if (resultMap.containsKey(strArr[0])) { // Check if the current Station has already been encountered.

                    //Get existing value object
                    StationTMAXDataClass stationTMAXDataClass = resultMap.get(strArr[0]);

                    //Accumulate running sum and count
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]) + stationTMAXDataClass.getSum());
                    stationTMAXDataClass.setCount(stationTMAXDataClass.getCount() + 1);

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    resultMap.put(strArr[0], stationTMAXDataClass);
                } else {

                    //Instantiate new Station Object
                    StationTMAXDataClass stationTMAXDataClass = new StationTMAXDataClass();

                    //Set first count and sum
                    stationTMAXDataClass.setCount(1);
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]));

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    resultMap.put(strArr[0], stationTMAXDataClass);
                }
        }

        //Call to average calculating function and store result
        Map<String, Double> result = calculateAVG(resultMap);

        //Print Total Time Taken for Execution
        System.out.println(System.currentTimeMillis() - start);

        //Block for printing all averages
        /*for (String key : result.keySet()) {
            System.out.println(key + "," + result.get(key));
        }*/
    }

    //Helper Function
    public Map<String, Double> calculateAVG(Map<String, StationTMAXDataClass> resultMap) {

        //Map for storing average of each station
        Map<String, Double> result = new HashMap();

        //Iterate through the Accumulated Map of all Stations
        for (String key : resultMap.keySet()) {

            //Get Value Object
            StationTMAXDataClass stationTMAXDataClass = resultMap.get(key);

            //Calculate Average for that Station
            Double avg = stationTMAXDataClass.getSum() / stationTMAXDataClass.getCount();

            //Add average to Map
            result.put(key, avg);
        }

        //return resulting Map
        return result;
    }
}
