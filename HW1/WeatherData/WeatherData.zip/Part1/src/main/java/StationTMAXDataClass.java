/**
 * Created by DJ on 1/24/17.
 * This is the Universal Station Data Object.
 * It consists of the corresponding Sum & Count and provides get() and set() functions.
 */
public class StationTMAXDataClass {
    double sum;
    int count;

    public double getSum() {
        return sum;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "StationTMAXDataClass{" +
                "sum=" + sum +
                ", count=" + count +
                '}';
    }
}
