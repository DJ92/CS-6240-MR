import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by DJ on 1/27/17.
 * This is the Fine Lock Thread Class for parallel execution of accumulating sums and counts of all subsets of data.
 */
public class FineLockedTMAXAvgThreadClass implements Runnable{

    //Local variable
    private List<String> listContent = new ArrayList<>();

    //Constructor
    public FineLockedTMAXAvgThreadClass(List<String> lC) {
        this.listContent = lC;
    }

    //Run Method
    public void run() {

        //Loop for iterating through list of strings and accumulating "TMAX" Sums & Counts of all Stations.
        for (String s : this.listContent) {

            //Split each String
            String[] strArr = s.split(",");

            //Check for TMAX value rows
            if (strArr[2].equals("TMAX")) {
                if (FineLockTMAXClass.resultMap.containsKey(strArr[0])) {  // Check if the current Station has already been encountered.

                    //In order to prevent stale values from being read by threads, atomic reference of the value of object has been created
                    AtomicReference<StationTMAXDataClass> atomicReference = new AtomicReference<>(FineLockTMAXClass.resultMap.get(strArr[0]));

                    //The getAndSet() function reads the latest updated value from declared reference for correct updation to the accumulator
                    StationTMAXDataClass stationTMAXDataClass = atomicReference.getAndSet(FineLockTMAXClass.resultMap.get(strArr[0]));

                    //Accumulate running sum and count
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]) + stationTMAXDataClass.getSum());
                    stationTMAXDataClass.setCount(stationTMAXDataClass.getCount() + 1);

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    FineLockTMAXClass.resultMap.put(strArr[0], stationTMAXDataClass);
                } else {

                    //Instantiate new Station Object
                    StationTMAXDataClass stationTMAXDataClass = new StationTMAXDataClass();

                    //Set first count and sum
                    stationTMAXDataClass.setCount(1);
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]));

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    FineLockTMAXClass.resultMap.put(strArr[0], stationTMAXDataClass);
                }
            }
        }
    }
}
