import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * Created by DJ on 1/25/17.
 * This is the No Shared Map Thread Class for parallel execution of accumulating sums and counts of all subsets of data.
 */
public class NoSharingTMAXAvgThreadClass implements Callable<Map<String, StationTMAXDataClass>> {

    //Local Map
    public Map<String, StationTMAXDataClass> resultMap = new HashMap();

    //Local Variable
    private List<String> listContent = new ArrayList<>();

    //Constructor
    public NoSharingTMAXAvgThreadClass(List<String> lC) {
        this.listContent = lC;
    }

    //Call Method that returns map as result
    public Map<String, StationTMAXDataClass> call() {

        //Loop for iterating through list of strings and accumulating "TMAX" Sums & Counts of all Stations.
        for (String s : this.listContent) {

            //Split each String
            String[] strArr = s.split(",");

            //Check for TMAX value rows
            if (strArr[2].equals("TMAX"))
                if (resultMap.containsKey(strArr[0])) { // Check if the current Station has already been encountered.

                    //Get existing value object
                    StationTMAXDataClass stationTMAXDataClass = resultMap.get(strArr[0]);

                    //Accumulate running sum and count
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]) + stationTMAXDataClass.getSum());
                    stationTMAXDataClass.setCount(stationTMAXDataClass.getCount() + 1);

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    resultMap.put(strArr[0], stationTMAXDataClass);
                } else {

                    //Instantiate new Station Object
                    StationTMAXDataClass stationTMAXDataClass = new StationTMAXDataClass();

                    //Set first count and sum
                    stationTMAXDataClass.setCount(1);
                    stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]));

                    //Fibonacci Call
                    //new Fibonacci(17);

                    //Update Map with new Sums and Counts for that Station
                    resultMap.put(strArr[0], stationTMAXDataClass);
                }
        }

        //return resulting Map
        return resultMap;
    }
}
