/**
 * Created by DJ on 1/27/17.
 * This class executes the Fibonacci series for a given number.
 */
public class Fibonacci {

    //Constructor
    Fibonacci(int n) {

        //Array of results
        int[] result = new int[n];

        //Initial Values
        result[0] = 1;
        result[1] = 1;

        //Loop for calculating the series
        for (int i = 2; i < result.length; i++) {
            result[i] = result[i - 1] + result[i - 2];
        }
    }
}
