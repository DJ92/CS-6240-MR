import java.util.ArrayList;
import java.util.List;

/**
 * Created by DJ on 1/25/17.
 * This is the Coarse Lock Thread Class for parallel execution of accumulating sums and counts of all subsets of data.
 */
public class CoarseLockedTMAXAvgThreadClass implements Runnable {

    //Local variable
    private List<String> listContent = new ArrayList<>();

    //Constructor
    public CoarseLockedTMAXAvgThreadClass(List<String> lC) {
        this.listContent = lC;
    }

    //Run Method
    public void run() {

        //Loop for iterating through list of strings and accumulating "TMAX" Sums & Counts of all Stations.
        for (String s : this.listContent) {

            //Split each String
            String[] strArr = s.split(",");

            //Check for TMAX value rows
            if (strArr[2].equals("TMAX")) {

                //The synchronized block for locking the shared map when running two (or more) instances
                synchronized (CoarseLockTMAXClass.resultMap) {

                    if (CoarseLockTMAXClass.resultMap.containsKey(strArr[0])) { // Check if the current Station has already been encountered.

                        //Get existing value object
                        StationTMAXDataClass stationTMAXDataClass = CoarseLockTMAXClass.resultMap.get(strArr[0]);

                        //Accumulate running sum and count
                        stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]) + stationTMAXDataClass.getSum());
                        stationTMAXDataClass.setCount(stationTMAXDataClass.getCount() + 1);

                        //Fibonacci Call
                        //new Fibonacci(17);

                        //Update Map with new Sums and Counts for that Station
                        CoarseLockTMAXClass.resultMap.put(strArr[0], stationTMAXDataClass);
                    } else {

                        //Instantiate new Station Object
                        StationTMAXDataClass stationTMAXDataClass = new StationTMAXDataClass();

                        //Set first count and sum
                        stationTMAXDataClass.setCount(1);
                        stationTMAXDataClass.setSum(Double.parseDouble(strArr[3]));

                        //Fibonacci Call
                        //new Fibonacci(17);

                        //Update Map with new Sums and Counts for that Station
                        CoarseLockTMAXClass.resultMap.put(strArr[0], stationTMAXDataClass);
                    }
                }
            }
        }
    }
}
