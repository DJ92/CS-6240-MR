import org.apache.hadoop.fs.Stat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Created by DJ on 1/25/17.
 * This is the Multithreaded TMAX Average Calculation of Stations with No Shared Map Implementation
 */
public class NoSharingTMAXClass {

    //Number of Threads for parallel execution
    int noThreads = 4;

    //ExecutorService Instance for creating a thread pool
    ExecutorService service = Executors.newFixedThreadPool(noThreads);

    //Future of Map Type
    //Future is a general concurrency abstraction, also known as a promise, which promises to return a result in future
    Future<Map<String, StationTMAXDataClass>> task;

    //Consolidated list of maps from different threads for accumulating sums and counts
    List<Map<String, StationTMAXDataClass>> resultMaps = new ArrayList<>();

    //Constructor
    public NoSharingTMAXClass(List<String> listContent) throws InterruptedException, ExecutionException, TimeoutException {
        System.out.print("NO SHARING: ");

        //List of Subsets from the consolidated list of strings
        List<List<String>> subset = new ArrayList<>();

        //Default size of each subset
        int size = listContent.size() / noThreads;

        //Staring Execution Time
        Long start = System.currentTimeMillis();

        //Loop to instantiate total number of threads
        for (int k = 0; k < noThreads; k++) {

            //Condition for last subset
            if (k == noThreads - 1)
                subset.add(listContent.subList(size * k, listContent.size()));
            else
                subset.add(listContent.subList(size * k, size * (k + 1)));

            //ExecutorService submits NoSharingTMAXAvgThreadClass with subset to thread pool for execution
            task = service.submit(new NoSharingTMAXAvgThreadClass(subset.get(k)));

            //Add the resulting map to consolidated list
            resultMaps.add(task.get(10, TimeUnit.SECONDS));
        }

        //service termination
        service.shutdown();
        service.awaitTermination(1, TimeUnit.SECONDS);

        //Call to function calculating TMAX Average of all Stations
        Map<String, Double> avgResult = calculateAVG(resultMaps);

        //Total Time Taken for Execution
        System.out.println(System.currentTimeMillis() - start);

        //Block for printing all averages
        /*for (String key : avgResult.keySet()) {
            System.out.println(key + "," + avgResult.get(key));
        }*/
    }

    //Helper Function
    public Map<String, Double> calculateAVG(List<Map<String, StationTMAXDataClass>> resultMaps) {

        //Map for consolidating sums and counts of each station
        Map<String, StationTMAXDataClass> tempMap = new HashMap();

        //Map for storing average of each station
        Map<String, Double> avgMap = new HashMap();

        //Iterate through the list of Thread Results
        for (Map<String, StationTMAXDataClass> entry : resultMaps) {

            //Iterate through the Accumulated Map of Stations for One Thread
            for (String key : entry.keySet()) {

                // Check if the current Station has already been encountered.
                if (tempMap.containsKey(key)) {

                    //Get Value Object
                    StationTMAXDataClass tempStationTMAXDataClass = tempMap.get(key);

                    //Accumulate running sum and count
                    tempStationTMAXDataClass.setSum(entry.get(key).getSum() + tempStationTMAXDataClass.getSum());
                    tempStationTMAXDataClass.setCount(entry.get(key).getCount() + tempStationTMAXDataClass.getCount());

                    //Update Map with new Sums and Counts for that Station
                    tempMap.put(key, tempStationTMAXDataClass);
                } else {

                    //Instantiate new Station Object
                    StationTMAXDataClass stationTMAXDataClass = new StationTMAXDataClass();

                    //Set first count and sum
                    stationTMAXDataClass.setSum(entry.get(key).getSum());
                    stationTMAXDataClass.setCount(entry.get(key).getCount());

                    //Update Map with new Sums and Counts for that Station
                    tempMap.put(key, stationTMAXDataClass);
                }
            }
        }

        //Map for storing average of each station
        for (String key : tempMap.keySet()) {

            //Get Value Object
            StationTMAXDataClass stationTMAXDataClass = tempMap.get(key);

            //Calculate Average for that Station
            Double avg = stationTMAXDataClass.getSum() / stationTMAXDataClass.getCount();

            //Add average to Map
            avgMap.put(key, avg);
        }

        //return resulting Map
        return avgMap;
    }
}
